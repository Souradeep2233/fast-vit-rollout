# Fast ViT Rollout 🚀

A robust, plug-and-play Attention Rollout extractor for Vision Transformers. Works seamlessly out of the box with `timm` and Hugging Face backbones.

### Why use this?
Most existing Attention Rollout scripts break on modern architectures. This package natively handles:
* **Flash Attention (SDPA):** Bypasses PyTorch 2.0+ fused attention issues.
* **Register Tokens:** Flawlessly parses DINOv2 and DeiT models without shape mismatch errors.
* **Auto-Detection:** Automatically hooks the correct layers without manual indexing.
* **Native Heatmaps:** Generates OpenCV-based overlays with built-in intensity colorbars.

### Installation
```bash
pip install fast-vit-rollout